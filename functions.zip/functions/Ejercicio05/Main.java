package Ejercicio05;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String nombre, apellido;
        int edad, dni;
        int horas, dias, meses, anios, sueldobase;
        System.out.println("Ingrese el nombre: ");
        nombre = sc.nextLine();
        System.out.println("Ingrese el apellido: ");
        apellido = sc.nextLine();
        System.out.println("Ingrese la edad: ");
        edad = sc.nextInt();
        System.out.println("Ingrese el dni: ");
        dni = sc.nextInt();
        Empleado empleado = new Empleado(nombre, apellido, edad, dni);

        System.out.println("Ingrese la cantidad de horas que trabajará " + empleado.getNombre() + " al día: ");
        horas = sc.nextInt();
        System.out.println("Ingrese la cantidad de días que trabajará " + empleado.getNombre() + " a la semana: ");
        dias = sc.nextInt();
        System.out.println("Ingrese la cantidad de meses que trabajará " + empleado.getNombre() + " al año: ");
        meses = sc.nextInt();
        System.out.println("Ingrese la cantidad de años que trabajará " + empleado.getNombre() + ": ");
        anios = sc.nextInt();
        Horario horario = new Horario(horas, dias, meses, anios);
        horario.setHoras(horas);
        horario.setDias(dias);
        horario.setMeses(meses);
        horario.setAnios(anios);

        System.out.println("Ingrese el sueldo base: ");
        sueldobase = sc.nextInt();
        sc.close();
        Sueldo sueldo = new Sueldo(sueldobase);

        System.out
                .println("El sueldo total de " + empleado.getNombre() + " es: " + sueldo.sueldoTotal(horario.getHoras(),
                        horario.getDias(), horario.getMeses(), horario.getAnios(), sueldobase));
        System.out.println("El sueldo por hora de " + empleado.getNombre() + " es: " + sueldo.sueldoPorHora(
                horario.getHoras(), horario.getDias(), horario.getMeses(), horario.getAnios(), sueldobase));
        System.out.println("El sueldo por día de " + empleado.getNombre() + " es: " + sueldo.sueldoPorDia(
                horario.getHoras(), horario.getDias(), horario.getMeses(), horario.getAnios(), sueldobase));
        System.out.println(
                "Las vocales de " + empleado.getNombre() + " en su nombre son: " + empleado.countVocalesNombre());
        System.out.println(
                "Las vocales de " + empleado.getNombre() + " en su apellido son: " + empleado.countVocalesApellido());

    }

}
