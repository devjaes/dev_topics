package Ejercicio05;

public class Sueldo {
    private int sueldoTotal;
    private int sueldoBase;
    private int sueldoHoras;
    private int sueldoAnio;
    public Horario horario;

    public Sueldo(int sueldoBase) {
        this.sueldoBase = sueldoBase;
    }

    public int getSueldoTotal() {
        if (horario.getHoras() > 8) {
            sueldoBase += 20;
            sueldoHoras = sueldoBase / (horario.getHoras());
            sueldoTotal = sueldoHoras * (horario.totalHoras());
            return sueldoTotal;
        } else {
            sueldoHoras = sueldoBase / (horario.getHoras());
            sueldoTotal = sueldoHoras * (horario.totalHoras());
            return sueldoBase;
        }
    }

    public int sueldoHoras() {
        if (horario.getHoras() > 8) {
            sueldoBase += 20;
            sueldoHoras = sueldoBase / (horario.getHoras());
            return sueldoHoras;
        } else {
            sueldoHoras = sueldoBase / (horario.getHoras());
            return sueldoHoras;
        }
    }

    public int sueldoAnio() {
        if (horario.getHoras() > 8) {
            sueldoBase += 20;
            sueldoHoras = sueldoBase / (horario.getHoras());
            sueldoAnio = sueldoHoras * (horario.getHorasAnio());
            return sueldoAnio;
        } else {
            sueldoHoras = sueldoBase / (horario.getHoras());
            sueldoAnio = sueldoHoras * (horario.getHorasAnio());
            return sueldoAnio;

        }
    }

}
